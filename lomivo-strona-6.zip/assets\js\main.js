document.documentElement.classList.replace('no-js', 'js');
window.lomivoReady = true;

/* lomivo · main.js · bez bibliotek, każdy moduł to osobne IIFE. */
const CONFIG = {
  CENA: "69 zł",
  // Stripe, konto Lomivo: Payment Link z BLIK, kartą, Link i Klarną.
  // Po płatności Stripe przenosi klienta na dziekujemy.html?sesja=… (adres ustawiony w linku w Stripe).
  LINK_PLATNOSCI: "https://buy.stripe.com/test_00wcN4dGVeJXboM1d2co001",
  OPERATOR_PLATNOSCI: "Stripe",
  FORM_ENDPOINT: "", // opcjonalnie np. https://formspree.io/f/xxxx; puste = wysyłka przez program pocztowy
  EMAIL: "lomivo@gmail.com"
};
const OPCJONALNE = ['FORM_ENDPOINT'];

const REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const $ = (s, c) => (c || document).querySelector(s);
const $$ = (s, c) => Array.prototype.slice.call((c || document).querySelectorAll(s));
const isMissing = (v) => typeof v === 'string' && (!v || v === '#' || /^\[.*\]$|\{\{/.test(v));
const raf = (f) => window.requestAnimationFrame(f);

function reportIncompleteConfig() {
  const miss = Object.keys(CONFIG).filter((k) => OPCJONALNE.indexOf(k) < 0 && isMissing(CONFIG[k]));
  if (miss.length) console.info('lomivo, konfiguracja do uzupełnienia:\n' + miss.map((k) => '  · ' + k + ': ' + (CONFIG[k] || '(puste)')).join('\n'));
}

function onView(els, cb) {
  if (REDUCED || !('IntersectionObserver' in window)) { els.forEach(cb); return; }
  const io = new IntersectionObserver((es) => es.forEach((e) => {
    if (e.isIntersecting) { io.unobserve(e.target); cb(e.target); }
  }), { threshold: 0.18, rootMargin: '0px 0px -8% 0px' });
  els.forEach((el) => io.observe(el));
}

// CONFIG → strona
(() => {
  reportIncompleteConfig();
  $$('[data-cfg]').forEach((el) => {
    const v = CONFIG[el.dataset.cfg];
    if (typeof v !== 'string' || !v) return;
    el.textContent = v;
    if (!isMissing(v)) el.classList.remove('ph');
  });
  const pay = CONFIG.LINK_PLATNOSCI;
  $$('[data-pay]').forEach((a) => {
    if (!isMissing(pay)) a.href = pay;
    else a.addEventListener('click', (e) => { e.preventDefault(); console.info('lomivo: brak CONFIG.LINK_PLATNOSCI'); });
  });
})();

// Nagłówek, pasek postępu, oś 30 dni (rAF)
(() => {
  const head = $('.site-header'), bar = $('.progress__bar'), track = $('.timeline__track');
  const fill = track && $('.timeline__fill', track), dots = $$('.timeline__dot');
  let queued = false;
  const update = () => {
    queued = false;
    const y = window.scrollY, max = document.documentElement.scrollHeight - window.innerHeight;
    if (head) head.classList.toggle('is-scrolled', y > 40);
    if (bar) bar.style.transform = 'scaleX(' + (max > 0 ? Math.min(y / max, 1) : 0) + ')';
    if (!fill || REDUCED) return;
    const line = window.innerHeight * 0.6, r = track.getBoundingClientRect();
    fill.style.transform = 'scaleY(' + Math.max(0, Math.min(1, (line - r.top) / r.height)) + ')';
    dots.forEach((d) => d.classList.toggle('is-on', d.getBoundingClientRect().top <= line));
  };
  const req = () => { if (!queued) { queued = true; raf(update); } };
  window.addEventListener('scroll', req, { passive: true });
  window.addEventListener('resize', req);
  update();
})();

// Kreska pod zakładkami
(() => {
  const nav = $('.nav__main'), ind = nav && $('.nav__indicator', nav);
  if (!ind) return;
  const links = $$('.nav__link', nav), cur = links.filter((a) => a.getAttribute('aria-current'))[0];
  const move = (a) => {
    if (!a || !a.offsetWidth) { ind.classList.remove('is-ready'); return; }
    ind.style.transform = 'translateX(' + (a.offsetLeft + 14) + 'px) scaleX(' + (a.offsetWidth - 28) / 100 + ')';
    ind.classList.add('is-ready');
  };
  const place = () => { ind.style.transition = 'none'; move(cur); void ind.offsetWidth; ind.style.transition = ''; };
  links.forEach((a) => { a.addEventListener('mouseenter', () => move(a)); a.addEventListener('focus', () => move(a)); });
  nav.addEventListener('mouseleave', () => move(cur));
  nav.addEventListener('focusout', (e) => { if (!nav.contains(e.relatedTarget)) move(cur); });
  place();
  window.addEventListener('resize', place);
  if (document.fonts) document.fonts.ready.then(place);
})();

// Menu mobilne
(() => {
  const btn = $('.nav__toggle'), menu = $('#menu');
  if (!btn || !menu) return;
  const items = () => $$('a[href], button', menu);
  const set = (open, back) => {
    menu.classList.toggle('is-open', open);
    document.documentElement.classList.toggle('menu-open', open);
    btn.setAttribute('aria-expanded', String(open));
    if (open) setTimeout(() => items()[0].focus(), 60);
    else if (back) btn.focus();
  };
  btn.addEventListener('click', () => set(true));
  menu.addEventListener('click', (e) => {
    if (e.target.closest('.mobile-menu__close')) set(false, true);
    else if (e.target.closest('a')) set(false);
    else if (!e.target.closest('li')) set(false, true);
  });
  document.addEventListener('keydown', (e) => {
    if (!menu.classList.contains('is-open')) return;
    if (e.key === 'Escape') { set(false, true); return; }
    if (e.key !== 'Tab') return;
    const f = items(), last = f[f.length - 1], at = document.activeElement;
    if (e.shiftKey && at === f[0]) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && at === last) { e.preventDefault(); f[0].focus(); }
  });
  const mq = window.matchMedia('(min-width: 900px)');
  if (mq.addEventListener) mq.addEventListener('change', (e) => { if (e.matches) set(false); });
})();

(() => { onView($$('.reveal, .reveal-group'), (el) => el.classList.add('is-visible')); })();

// Liczniki
(() => {
  const nums = $$('[data-count]');
  if (!nums.length || REDUCED || !('IntersectionObserver' in window)) return;
  nums.forEach((el) => { el.textContent = '0'; });
  onView(nums, (el) => {
    const end = Number(el.dataset.count), t0 = performance.now();
    const step = (now) => {
      const k = Math.min((now - t0) / 1100, 1);
      el.textContent = String(Math.round(end * (1 - Math.pow(1 - k, 3))));
      if (k < 1) raf(step);
    };
    raf(step);
  });
})();

// Sekwencja STOP
(() => {
  const grid = $('[data-stop]');
  if (!grid) return;
  const tiles = $$('.stop__tile', grid), all = () => tiles.forEach((t) => t.classList.add('is-active'));
  if (REDUCED) { all(); return; }
  let timers = [], started = false;
  onView([grid], () => {
    started = true;
    tiles.forEach((t, i) => timers.push(setTimeout(() => t.classList.add('is-active'), 300 + i * 700)));
  });
  if (!window.matchMedia('(hover: hover)').matches) return;
  tiles.forEach((t) => t.addEventListener('mouseenter', () => {
    timers.forEach(clearTimeout); timers = [];
    tiles.forEach((x) => x.classList.toggle('is-active', x === t));
  }));
  grid.addEventListener('mouseleave', () => { if (started) all(); });
})();

// Przechył okładki
(() => {
  const book = $('[data-tilt]');
  if (!book || REDUCED || !window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 900px)').matches) return;
  const zone = book.closest('section'), lim = (v) => Math.max(-1, Math.min(1, v)) * 6;
  let tx = 0, ty = 0, x = 0, y = 0, id = 0;
  const loop = () => {
    x += (tx - x) * 0.08; y += (ty - y) * 0.08;
    book.style.transform = 'rotateX(' + y.toFixed(2) + 'deg) rotateY(' + x.toFixed(2) + 'deg)';
    id = Math.abs(tx - x) + Math.abs(ty - y) > 0.01 ? raf(loop) : 0;
  };
  zone.addEventListener('mousemove', (e) => {
    const r = book.getBoundingClientRect();
    tx = lim((e.clientX - r.left - r.width / 2) / r.width);
    ty = lim((r.top + r.height / 2 - e.clientY) / r.height);
    book.classList.remove('is-returning');
    if (!id) id = raf(loop);
  });
  zone.addEventListener('mouseleave', () => {
    cancelAnimationFrame(id); id = 0; tx = ty = x = y = 0;
    book.classList.add('is-returning');
    book.style.transform = 'rotateX(0deg) rotateY(0deg)';
  });
})();

// Przejścia między stronami
(() => {
  if (REDUCED) return;
  const root = document.documentElement;
  window.addEventListener('pageshow', (e) => { if (e.persisted) root.classList.remove('is-leaving'); });
  document.addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if ((a.target && a.target !== '_self') || a.hasAttribute('download')) return;
    const u = new URL(a.href, location.href);
    if (u.protocol !== location.protocol || u.host !== location.host || !/^(https?|file):$/.test(u.protocol)) return;
    if (u.pathname === location.pathname && u.search === location.search) return;
    if (/\.(pdf|zip|svg|png|jpe?g|webp|txt|xml)$/i.test(u.pathname)) return;
    e.preventDefault();
    root.classList.add('is-leaving');
    setTimeout(() => { location.href = u.href; }, 240);
  });
})();

// Akordeony (Escape zamyka)
(() => {
  const set = (it, open) => {
    it.classList.toggle('is-open', open);
    $('.acc__btn', it).setAttribute('aria-expanded', String(open));
  };
  $$('[data-acc]').forEach((acc) => {
    $$('.acc__btn', acc).forEach((btn) => {
      const it = btn.closest('.acc__item');
      set(it, it.classList.contains('is-open'));
      btn.addEventListener('click', () => set(it, !it.classList.contains('is-open')));
      it.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && it.classList.contains('is-open')) { set(it, false); btn.focus(); }
      });
    });
  });
  const fromHash = () => {
    const t = location.hash && document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (t && t.classList.contains('acc__item')) set(t, true);
  };
  fromHash();
  window.addEventListener('hashchange', fromHash);
})();

// Dolny pasek zakupu
(() => {
  const bar = $('[data-buybar]'), hero = $('[data-buy-hero]'), card = $('#kup .price-card');
  if (!bar || !hero || !card) return;
  let queued = false;
  const update = () => {
    queued = false;
    const h = window.innerHeight, c = card.getBoundingClientRect();
    bar.classList.toggle('is-shown', hero.getBoundingClientRect().bottom < 0 && (c.top > h || c.bottom < 0));
  };
  window.addEventListener('scroll', () => { if (!queued) { queued = true; raf(update); } }, { passive: true });
  update();
})();

// Pobieranie tylko po powrocie ze Stripe (?sesja=cs_…)
(() => {
  const box = $('[data-download]'), none = $('[data-download-missing]');
  if (!box || !none) return;
  const paid = /[?&]sesja=cs_/.test(location.search);
  box.hidden = !paid;
  none.hidden = paid;
})();

// Formularz
(() => {
  const form = $('[data-form]'), btn = form && $('[data-submit]', form), status = form && $('[data-status]', form);
  if (!btn || !status) return;
  const mail = CONFIG.EMAIL, el = (n) => form.elements[n], val = (n) => el(n).value.trim();
  form.noValidate = true;
  if (!CONFIG.FORM_ENDPOINT && $('[data-mailto-note]', form)) $('[data-mailto-note]', form).hidden = false;
  $$('[data-topic]').forEach((a) => a.addEventListener('click', () => {
    el('temat').value = a.dataset.topic;
    setTimeout(() => el('temat').focus(), 0);
  }));
  const rules = {
    imie: (v) => (v ? '' : 'Wpisz swoje imię.'),
    email: (v) => (!v ? 'Wpisz adres e-mail, na który mamy odpowiedzieć.'
      : /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Wpisz poprawny adres e-mail, np. anna@poczta.pl.'),
    temat: (v) => (v ? '' : 'Wybierz temat wiadomości.'),
    wiadomosc: (v) => (v ? '' : 'Napisz, w czym możemy pomóc.'),
    zgoda: (v, f) => (f.checked ? '' : 'Zaznacz zgodę, żebyśmy mogli odpowiedzieć na wiadomość.')
  };
  const check = (n) => {
    const f = el(n), msg = rules[n](f.value.trim(), f), err = document.getElementById('e-' + n);
    if (msg) f.setAttribute('aria-invalid', 'true'); else f.removeAttribute('aria-invalid');
    if (err) { err.textContent = msg; err.hidden = !msg; }
    return msg ? f : null;
  };
  Object.keys(rules).forEach((n) => {
    el(n).addEventListener(n === 'zgoda' ? 'change' : 'input', () => { if (el(n).hasAttribute('aria-invalid')) check(n); });
  });
  const setBtn = (html, state) => {
    btn.innerHTML = html;
    btn.disabled = state === 'busy' || state === 'ok';
    btn.classList.toggle('is-ok', state === 'ok');
    btn.setAttribute('aria-busy', String(state === 'busy'));
  };
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    status.textContent = '';
    status.classList.remove('is-error');
    const bad = Object.keys(rules).map(check).filter(Boolean);
    if (bad.length) { bad[0].focus(); return; }
    if (!CONFIG.FORM_ENDPOINT) {
      location.href = 'mailto:' + mail + '?subject=' + encodeURIComponent('[lomivo] ' + val('temat')) +
        '&body=' + encodeURIComponent(val('wiadomosc') + '\n\n' + val('imie') + ' (' + val('email') + ')');
      status.textContent = 'Otwieramy Twój program pocztowy z gotową wiadomością. Jeśli się nie otworzył, napisz na ' + mail + '.';
      return;
    }
    setBtn('<span class="dot" aria-hidden="true"></span>Wysyłam…', 'busy');
    fetch(CONFIG.FORM_ENDPOINT, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
      .then((res) => {
        if (!res.ok) throw new Error(res.status);
        form.reset();
        setBtn('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Wiadomość wysłana', 'ok');
        status.textContent = 'Dziękujemy. Odpowiemy w ciągu 24 godzin w dni robocze.';
      })
      .catch(() => {
        setBtn('Spróbuj ponownie', 'error');
        status.classList.add('is-error');
        status.textContent = 'Nie udało się wysłać wiadomości. Spróbuj ponownie albo napisz na ' + mail + '.';
      });
  });
})();
